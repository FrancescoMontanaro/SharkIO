function size_clicked(event){
    let size = event.target;
    let current_size = get_child_by_class(get_child_by_class(size.closest('.dropdown'), 'dropdownBtn'), 'size');
    let arrow = get_child_by_class(get_child_by_class(size.closest('.dropdown'), 'dropdownBtn'), 'arrow');
    let dropdown_content = size.closest('.dropdown-content');
    console.log(size.value)
    current_size.innerHTML = size.value == 0 ? "any":size.value;
    arrow.style.transform = "rotate(0)";
    dropdown_content.style.display = "none";
}

function get_child_by_class(elem, c){
    for(child of elem.childNodes){
        if(child.classList)
            if(child.   classList.contains(c))
                return child;
    }
}
document.getElementById("onOff" +"Onygo").addEventListener('dbclick', function(){
    //changeValueChromeOnOff("onOff" "Onygo");
   console.log("cliccato" +"onOff new" +"Onygo" );});
function show_hide_size(event){
    let target = event.target;
    let parent = target.closest('div');

    let dropdown_content = get_child_by_class(parent, 'dropdown-content');
    let arrow = get_child_by_class(get_child_by_class(parent, 'dropdownBtn'), 'arrow');

    if(dropdown_content.style.display == "block"){
        dropdown_content.style.display = "none";
        arrow.style.transform = "rotate(0)";
        
    }
    else{
        dropdown_content.style.display = "block";
        arrow.style.transform = "rotate(180deg)";
    }
}

function show_settings(){
    document.getElementById('settings').style.display = 'block';
    //console.log("sono in showSettings");
}

// Qua andrà chiamata la funzione server che controlla la licenza - DA IMPLEMENTARE
function check_license(){
    document.getElementById('license').style.display = 'none';
    console.log("sono nella parte del controllo della licenza");
    const arr=["onygoSize","zalandoSize","snsSize","supremeSize","soleboxSize","snipesSize"];
    console.log("la lunghezza di arr e"+ arr.length)
    for (let x = 0; x<arr.length;x++){
        setTimeout(SetValuesHtml(arr[x],10));
    }
    const arr1= ["Onygo","Zalando","Sns","Supreme","Solebox","Snipes"]
    for (let x = 0; x<arr1.length;x++){
        setTimeout(SetValuesHtmlOnOff("indicator" +arr1[x],10));
    }
}
const arr1= ["Onygo","Zalando","Sns","Supreme","Solebox","Snipes"]
for (let x = 0; x<arr1.length;x++){
    // in questo caso vuol dire che utente preme il tasto off e quindi
    //la funzione mettera false nell browser 
    //toggle indicator
    console.log("toggle" +arr1[x]);
    try {
        document.getElementById("toggle" +arr1[x]).addEventListener('click', function(){
            changeValueChromeOnOff("toggle" +arr1[x]);
           console.log("cliccato" +"toggle" +arr1[x] );});
    } catch (error) {
        continue;
    }
    

}
// Funzione di logout - DA IMPLEMENTARE
function logout(){
    return;
}


function close_settings(){
    document.getElementById('settings').style.display = 'none';
}

document.getElementById('licenseActivationBtn').addEventListener('click', function(){
    check_license();
});

document.getElementById('closeSettingsBtn').addEventListener('click', function(){
    close_settings();
});

document.getElementById('logoutBtn').addEventListener('click', function(){
    logout();
});

document.getElementById('showSettingsBtn').addEventListener('click', function(){
    show_settings();
});
//document.getElementById("onygoSize").innerHTML=20;
//document.getElementById('onygoSize').addEventListener('mouseover', function(){
//    document.getElementById("onygoSize").innerHTML=30;
//});
//indicatorOnygo
//document.getElementById('indicatorOnygo').addEventListener('click', function(){
    //console.log("cliccato indicatorOnygo per chiudere programma");
    //console.log("io sono qua dentro")
//});
for(elem of document.getElementsByClassName('dropdownBtn')){
    elem.addEventListener('click', function(event){
        show_hide_size(event);
    });
}

for(elem of document.getElementsByClassName('sizeItem')){
    elem.addEventListener('click', function(event){
        size_clicked(event);
    });

}
//set the info about the settings from the browser
for(elem of document.getElementsByClassName('sizeItemonygo')){
    elem.addEventListener('click', function(event){
        size_clicked(event);
        let size = event.target;
        value=size.value;
        setSiteValue("onygoSize",value);
    });

}
for(elem of document.getElementsByClassName('sizeItezalando')){
    elem.addEventListener('click', function(event){
        size_clicked(event);
        let size = event.target;
        value=size.value;
        setSiteValue("zalandoSize",value);
    });

}
for(elem of document.getElementsByClassName('sizeItesns')){
    elem.addEventListener('click', function(event){
        size_clicked(event);
        let size = event.target;
        value=size.value;
        setSiteValue("snsSize",value);
    });

}
for(elem of document.getElementsByClassName('sizeItesolebox')){
    elem.addEventListener('click', function(event){
        size_clicked(event);
        let size = event.target;
        value=size.value;
        setSiteValue("soleboxSize",value);
    });

}
for(elem of document.getElementsByClassName('sizeItesupreme')){
    elem.addEventListener('click', function(event){
        size_clicked(event);
        let size = event.target;
        value=size.value;
        setSiteValue("supremeSize",value);
    });

}
for(elem of document.getElementsByClassName('sizeItesnipes')){
    elem.addEventListener('click', function(event){
        size_clicked(event);
        let size = event.target;
        value=size.value;
        setSiteValue("snipesSize",value);
    });

}
//set the values inside the browser
function setSiteValue(site,value){
    chrome.storage.local.set({[site]: value}, function() {
        //console.log('Value is set to ' );
        console.log(value  + site + " is setted");
      });}
//return the info about the settings, have to extend this in a json file that does this in auto
function SetValuesHtml(site){//pass a value like onygoSize
    try {
        chrome.storage.local.get([site], function(result) {
            value = result[[site]]; 
           
            console.log("setted on html the value of :  " + JSON.stringify(result));
            if (value>30){
                document.getElementById(site).innerHTML=value;
            }
        });
    } catch (error) {
        
    }
  

}
function SetValuesHtmlOnOff(site){//pass a value like indicatorOnygo s
    try {
        chrome.storage.local.get([site], function(result) {
            value = result[[site]]; 
           
            console.log("on off   " + site+ JSON.stringify(result));
            if (value){
                console.log("clicked")
                document.getElementById(site).click();
            }
        });
    } catch (error) {
        
    }
}
function returnValueOnOff(site){//pass a value like indicatorOnygo s
    try {
        chrome.storage.local.get([site], function(result) {
            value = result[[site]]; 
           
            console.log("the value is   " + value+ JSON.stringify(result));
            if (value){
                return true;
            }
            else{
                return false;
            }
        });
    } catch (error) {
        return false;
    }
}
function returnValueOnOff1(site){//pass a value like indicatorOnygo s
    try {
        chrome.storage.local.get([site], function(result) {
            value = result[[site]]; 
            if (value==null){
                console.log("ritorno quindi 0")
                return 0;
            }
            //console.log("the value is   " + value+ JSON.stringify(result));
            if (value>0){
                console.log("continua a entrare qua dentro ")
                return 1;
            }
            else{
                return 0;
            }
        });
    } catch (error) {
        return 0;
    }
}
function changeValueChromeOnOff(site){//pass a value like indicatorOnygo true or false based on setvalueshtmlOnOff
    try {
        var value;
        var boolean;
        console.log(returnValueOnOff1(site +"value" ));
        if (returnValueOnOff1(site +"value" )==0){
            console.log("prima parte primo blocco");
            chrome.storage.local.set({[site+"value"]: 1}, function() {
                //console.log('Value is set to ' );
                console.log("primo blocco");

              });
            return;
        }
        else if (returnValueOnOff1(site+"value")==1){
            chrome.storage.local.set({[site+"value"]: 0}, function() {
                //console.log('Value is set to ' );
                
              });
            console.log("secondo  blocco")
            value = 1;
        }
        chrome.storage.local.set({[site]: ! (returnValueOnOff(site))}, function() {
            //console.log('Value is set to ' );
            console.log("change the value in chrome of"  + site + " is setted");
          });
    } catch (error) {
        
    }
}
function changeValueChromeOn(site){//pass a value like indicatorOnygo true or false based on setvalueshtmlOnOff
    try {
        chrome.storage.local.set({[site]: ! returnValueOnOff(site)}, function() {
            //console.log('Value is set to ' );
            console.log("change the value in chrome of"  + site + " is setted");
          });
    } catch (error) {
        
    }
}
//what to do if this is the first time the program run
function FirstTime(){
    if (CheckFirstTime()){

    }
}
//one of the function of the first time and what to do 
function CheckFirstTime(){
    try {
        chrome.storage.local.get(["firstTime"], function(result) {
            value = result[[FirstTime]]; 
           
            console.log("First time is  :  " + JSON.stringify(result));
            if (value>30){
                console.log("maggiore di 30 posso effetturare tutte le misurazioni")
                return true;
            }
            else{
                return false
            }
        });
    } catch (error) {
        return false;
    }
}