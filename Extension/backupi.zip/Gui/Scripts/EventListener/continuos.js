//qua sono messi quelli per controllare se un sito e attivo o no e anche per controllare che sia cliccato o no
//una size di una scarpa e questo aggiornera tutto 
//scrivere nome di dove il browser andra a prendere le cose 
