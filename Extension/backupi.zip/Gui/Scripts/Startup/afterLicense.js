//quello che voglio fare dopo che e passato il controllo della licenza
//e semplicemente mettere sia la size allocata nel browser che anche on e off

function check_license(){
    document.getElementById('license').style.display = 'none';
    console.log("sono nella parte del controllo della licenza");
    const arr=["onygoSize","zalandoSize","snsSize","supremeSize","soleboxSize","snipesSize"];
    console.log("la lunghezza di arr e"+ arr.length)
    //set the values for the size so this is the size
    for (let x = 0; x<arr.length;x++){
        setTimeout(SetValuesHtml(arr[x],10));
    }
    //set the value to use script in a site 
    //const arr1= ["Onygo","Zalando","Sns","Supreme","Solebox","Snipes"]
    //for (let x = 0; x<arr1.length;x++){
    //    setTimeout(SetValuesHtmlOnOff("indicator" +arr1[x],10));
    //}
}

//non principal function to set the size in the html 
function SetValuesHtml(site){//pass a value like onygoSize
    try {
        chrome.storage.local.get([site], function(result) {
            value = result[[site]]; 
           
            console.log("setted on html the value of :  " + JSON.stringify(result));
            if (value>30){
                document.getElementById(site).innerHTML=value;
            }
        });
    } catch (error) {
        
    }
  

}